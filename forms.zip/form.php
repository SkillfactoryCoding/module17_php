
<h1> Из какого Вы города? </h1>
<form action="" method="GET">
	<input type="text" name="city">
	<input type="submit">
</form>

<?php
	//Если форма была отправлена и поле ввода не пустое:
	if (!empty($_REQUEST['city'])) {
		$city = $_REQUEST['city'];
        echo 'Ваш город: '.$city;
    }
    $arr = explode('31-12-2025');
	echo mktime(0, 0, 0, $arr[1], $arr[0], $arr[2]);
?>