<?php
session_start();
const SOL = 'kjyhjkl2478uguyg';
$link = mysqli_connect('127.0.0.1', 'root', '', 'users');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (empty($_POST['login']) || empty($_POST['password'])) {
		header('location /');
		exit(); // в коде лучше не использовать exit(). Здесь для простого примера
	}

	$login = $_POST['login'];
	$password = $_POST['password'];

	$sql = "SELECT id, login, password FROM users WHERE login = '$login'";
	$result = mysqli_query($link, $sql);
	$row = mysqli_fetch_assoc($result);
	if (empty($row)) {
		header('location: /');
	}

	if (password_verify ($password, $row['password'])) {
		$_SESSION['auth'] = true;
	}
	header('location: /');
}

if (!empty($_GET['exit'])) {
	session_destroy();
	header('location: /');
}


if (!empty($_SESSION['auth'])) {
	echo <<<EOT
	<h1> Добро пожаловать! </h1>
	<a href="?exit=1"> Выйти </a>
EOT;

} else {
	echo <<<EOT
	<form method="post">
	<input type="text" name="login" placeholder="login">
	<input type="text" name="password" placeholder="password">
	<input type="submit">
	</form>
EOT;
}

?>

<?php


if (!empty($_REQUEST)) {
	if($_REQUEST['test'] == '1') echo 'example1';
	if($_REQUEST['test'] == '2') echo 'example2';
	if($_REQUEST['test'] == '3') echo 'example3';
}
$sentense = 'example';
?>

<form action ="" method="GET">
	<select name="test[]"multiple>
		<option value="1">  example1 </option> 
		<option value="2">  example2 </option>
		<option value="3" selected> example3 </option>
	</select>
	<input type="submit" value="отправить" name="submit">
</form>




<!--<form action="" method="GET">
	<input name="user" value="">
	<input type="submit">	
</form> -->

<!--
//if(isset($_REQUEST['user'])) echo $_REQUEST['user']; 
//?> -->

<!--<input type="radio" name="test" value="1" checked> 
	<input type="radio" name="test" value="2"> 
    <input type="hidden" name="test" value="0"> 
	<input type="checkbox" name="test" value="1">-->