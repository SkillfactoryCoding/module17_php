# Простой скрипт загрузки файлов на PHP

## Запуск

1. `git clone https://github.com/SkillfactoryCoding/module17_php`
2. `cd php_file_upload_example`
3. `php -S localhost:8080`

