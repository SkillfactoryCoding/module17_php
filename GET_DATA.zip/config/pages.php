<?php
return array(
'1' => 'home.php',
'2' => 'users.php',
'3' => 'user.php',
);
