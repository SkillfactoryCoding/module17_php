<?php
include 'config/lib.php';
$pages = include 'config/pages.php';
$page = getPage($pages);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<ul>
		<li><a href="?page=1">Главная</a></li>
		<li><a href="?page=2">Пользователи</a></li>
		<li><a href="?page=3">Пользователь</a></li>
	</ul>

<?php

include 'pages/' . $page;

?>

</body>
</html>


