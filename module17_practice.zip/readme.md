# Простой скрипт галереи изображений на PHP

## Запуск

1. `git clone git https://github.com/SkillfactoryCoding/module17_php/php_image_gallery_example.git`
2. `cd php_image_gallery_example`
3. `php -S localhost:8080`

